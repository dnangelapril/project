package com.home.currency;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    private  EditText ntd;
    private String title;
    private String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }

    private  void findViews(){
        ntd = findViewById(R.id.ntd);
        Button GO =  findViewById(R.id.button);

        GO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String money = ntd.getText().toString();

                if (money.equals("")){
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Problem")
                            .setMessage("Please enter you NTD amount")
                            .setPositiveButton("OK", null)
                            .show();
                }
                else{
                    float m = Float.parseFloat(money);
                    float conversion = m / 30.9f;
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Result")
                            .setMessage("USD is " + conversion)
                            .setPositiveButton("OK", null)
                            .show();
                }
            }
        });
    }
}
